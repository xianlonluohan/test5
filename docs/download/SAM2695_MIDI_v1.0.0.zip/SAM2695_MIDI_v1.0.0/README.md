# Emakefun SAM2695 MIDI

## Introduction

SAM2695 MIDI module library. The SAM2695 MIDI module is a module used for synthesizing sound sources, with 128 universal MIDI sounds, a set of 128 variants, and dozens of percussion sounds. It can play ineffective 64 tone polyphonic music, as well as effective 38 tone music.
